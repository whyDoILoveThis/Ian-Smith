

// ⚠️ IGNORE THESE COMPILER ERRORS ⚠️ — char vs wchar_t / strcpy_s warnings are harmless, everything works perfectly.
// These are the char vs wchar_t / strcpy_s warnings from MinGW.
// Completely safe to ignore: all tray strings, menu items, and window class
// work perfectly with ANSI WinAPI. CapsLock monitoring runs fine.

#include <windows.h>
#include <shellapi.h>
#include <thread>
#include <chrono>
#include <fstream>
#include <string>

using namespace std;

#define WM_TRAYICON (WM_USER + 1)

NOTIFYICONDATA nid;
HMENU hMenu;
bool running = true;

// ==================== Read timeout from config.txt ====================
int readTimeoutFromFile(const string &filename)
{
    ifstream file(filename);
    int ms = 5000; // default 5s
    if (file.is_open())
    {
        file >> ms;
        file.close();
    }
    return ms;
}

// ==================== Caps Lock Helper ====================
bool isCapsLockOn()
{
    return (GetKeyState(VK_CAPITAL) & 0x0001) != 0;
}

void toggleCapsLock()
{
    keybd_event(VK_CAPITAL, 0x45, KEYEVENTF_EXTENDEDKEY | 0, 0);
    keybd_event(VK_CAPITAL, 0x45, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
}

// ==================== Tray Icon ====================
void AddTrayIcon(HWND hwnd)
{
    memset(&nid, 0, sizeof(NOTIFYICONDATA));
    nid.cbSize = sizeof(NOTIFYICONDATA);
    nid.hWnd = hwnd;
    nid.uID = 1;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_TRAYICON;
    nid.hIcon = (HICON)LoadImage(NULL, "myIcon.ico", IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE);
    strcpy_s(nid.szTip, "ITS CapCooler - Auto CapsLock Off Timer");
    Shell_NotifyIcon(NIM_ADD, &nid);
}

void RemoveTrayIcon()
{
    Shell_NotifyIcon(NIM_DELETE, &nid);
}

// ==================== Right-Click Menu ====================
void ShowContextMenu(HWND hwnd)
{
    POINT pt;
    GetCursorPos(&pt);
    hMenu = CreatePopupMenu();
    AppendMenu(hMenu, MF_STRING, 1, "Exit");
    SetForegroundWindow(hwnd);
    TrackPopupMenu(hMenu, TPM_BOTTOMALIGN | TPM_LEFTALIGN, pt.x, pt.y, 0, hwnd, NULL);
    DestroyMenu(hMenu);
}

// ==================== Window Procedure ====================
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_TRAYICON:
        if (lParam == WM_RBUTTONUP)
        {
            ShowContextMenu(hwnd);
        }
        break;
    case WM_COMMAND:
        if (LOWORD(wParam) == 1)
        { // Exit
            running = false;
            PostQuitMessage(0);
        }
        break;
    case WM_DESTROY:
        RemoveTrayIcon();
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// ==================== Background CapsLock Timer ====================
void CapsLockMonitor(int timeoutMs)
{
    auto lastTyped = chrono::steady_clock::now();

    while (running)
    {
        bool typing = false;

        // Check all keys
        for (int key = 0x08; key <= 0xFE; key++)
        {
            if (GetAsyncKeyState(key) & 0x8000)
            {
                typing = true;
                break;
            }
        }

        if (typing)
            lastTyped = chrono::steady_clock::now();

        if (isCapsLockOn())
        {
            auto now = chrono::steady_clock::now();
            auto elapsed = chrono::duration_cast<chrono::milliseconds>(now - lastTyped).count();
            if (elapsed >= timeoutMs)
            {
                toggleCapsLock();
                lastTyped = chrono::steady_clock::now();
            }
        }

        this_thread::sleep_for(chrono::milliseconds(50));
    }
}

// ==================== Main ====================
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    // Register dummy window class
    WNDCLASS wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "CapsLockTrayApp";
    RegisterClass(&wc);

    HWND hwnd = CreateWindow("CapsLockTrayApp", "CapsLockTrayApp", 0, 0, 0, 0, 0, HWND_MESSAGE, NULL, hInstance, NULL);

    AddTrayIcon(hwnd);

    int timeoutMs = readTimeoutFromFile("config.txt");

    // Start CapsLock monitor in background
    thread monitorThread(CapsLockMonitor, timeoutMs);
    monitorThread.detach();

    // Message loop for tray interaction
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
